#ifndef __PREPROCESS_H__
#define __PREPROCESS_H__
#include <vector>
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <stdlib.h>
#include <algorithm>
using namespace std;

#define WITHIN(a, b, c)  (((c)>=(a)) && ((c)<=(b))) || (((c)<=(a)) && ((c)>=(b))) 

void readLibFile(char *ftestname);
void stitchCellPolygons();

/*-----------------------------------------------------------------------------------------------------------------------------
Data structure to represent the node in the solution graph
-----------------------------------------------------------------------------------------------------------------------------*/
typedef struct _NODE{
	int ID, cost, distance;  //in each cut, we assigned a node with an unique ID
	// distance is used in the shortest path algorithm
	// one stitch correspond to cost 1
//	vector<_NODE *>  next;
	map<int, char> cutline;     // polygon ID, color
	map<_NODE *, int> next; //descents of current node in the solution graph, <node, cost>
	map<_NODE *, int> pre;  // parents nodes of current nodes <node, cost>
	set<_NODE *>  preNode;  // used in shortest path algorithm
	_NODE* optimalNext;   // for xfig, to draw the optimal solution
}node;


/*-----------------------------------------------------------------------------------------------------------------------------
Data structure to construct a tree when enumerate the colors of one cutline
-----------------------------------------------------------------------------------------------------------------------------*/
typedef struct __treeNode{
	int index;
	char color;
	__treeNode *p;
	__treeNode *left, *middle, *right;
}treeNode;

typedef struct _EDGE{
	int thisX, thisY;
	int thatX, thatY;
	int index;  // denote the ID of the polygons conflicting with this edge
}edge;


class polygon{
public:
	polygon();
	polygon(int num);
	polygon(int , int , int , int, int, int ,int);
	polygon(polygon *& a);

	int numVertix;
	int leftB,rightB,upB;   //the left most X coordinate
	int virtualRight,index,area,parentID;
	vector< pair<int,int> > vertXYCoord;
	vector<edge *> conflictEdge;  // added for ICCAD. the conflict edge of this polygon with others 
	set<int> constraintID;
	set<int> connectID;   //denotes the index connected with current polygon
	void decomposeRec();   //possibley decompose the polygon into some rectangles
	void parallelXEdge(edge *&, edge *&, int );
	void parallelYEdge(edge *&, edge *&, int );
	void orthogonalXEdge(edge *&, edge *&, int );
	void orthogonalYEdge(edge *&, edge *&, int );
	void geneConstraintEdge(edge *&, edge *&, int ); // added for ICCAD. 
};


/*-----------------------------------------------------------------------------------------------------------------------------
polygon within a standard are placed and named according to their leftmost x coordinate
In the constraint graph, the node number is internally the index in the vertor<polygon> storing the corresponding polygon
-----------------------------------------------------------------------------------------------------------------------------*/ 
class standardCell{
public:
	standardCell(){
	};
	standardCell(int, char *);

	char name[50];
	int numPloygon,leftB,rightB;
	vector<polygon *>  polygons;   //Note: the polygons should be stored according to the increasing X coordinates!
	vector<polygon *>  stitchPolygons;   // polygons after stitch candidate generation, power and ground the same color, added for ICCAD version
//	vector<polygon *>  diffStitchPolygons;   // polygons after stitch candidate generation, power and ground different color, added for ICCAD version
//	map<int, int>  partentID;         // added for ICCAD version. polygons after stitch candidate generation, its parent polygon ID
	// If two polygons share the same partentID, they belongs to the same parent polygon!
//	vector<int> area;  // Corresponding the area of the polygon, one to one correspondence to vector<polygon *>  polygons 
	//Once fixed, do not change the order of the pologons! 
	node * headSame, *headDiff;   //store the head node of the color solution, headSame: same color of VDD and GND
	vector<edge*> stitchEdgeVec;  // for debug, draw pictures
	double calPolygonDis(polygon *,int, polygon *, int);
	void checkConstraintP();      //check the constrainted polygon for all polygons in this standard cell
	void constraintGraph(bool);      //construct the constraint graph for the standard cell
	void virtualExtend();          // virtually extend the polygon to the right most constraint polygons
	bool enmurateColor(bool);
	void getBoundary();          // Get the right and left boudaries of the standard cell
	double calEdgeDis(edge *, edge * );
	bool checkGraphLegal(node *&,node *&);
	int determineEdgeCost(node *curr,node *next,set<int> &);
	int determineNodeCost(node *curr,set<int> & newPolygonID);
	int findAncestor(node *& solutionNode, set<node*>& currNode,set<int> &);
	bool checkLegal(int ID,treeNode *curr, char color);
	void freeTree(treeNode *);
	void assignNodeID(bool );
	void reduceGraph(set<node*> & );   // reduce the graph if the node has no descents
	bool constructNode(set<node*> &,  set<int> & , set<node*> &, bool,set<int> &);

	
	//since we extend the cell, two successive standard cells are only influenced by one cutline, we donot need to find polygon ID
	// within the "DISTANCE" of the boundaries. 
	~standardCell();
};



//extern map<string, standardCell *>  cellLib;
extern int LAYER;
extern int DISTANCE,stitchCandidate;
bool polygonIntersect(polygon *, polygon *);

#endif


