#include <stdio.h>
#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <cstring>
#include <algorithm>
#include <functional>
#include <sys/time.h>
#include <time.h>
#include <queue>
#include "include.h"
//#include "trippleColor.h"
#include "xfig.h"
using namespace std;
int  LAYER=-1;
int DISTANCE=820;
int totalStitchNum=0, stitchCandidate=0;
char sameFlag=1;
/*-----------------------------------------------------------------------------------------------------------------------------------------
Usage: ./tripple [a file including all the standardCell names in .txt format]  [benchmark]
[a file including all the standardCell names in .txt format] is used to construct the partical solution for all the standard
cells in the library. Format: (every row specifies a standard cell element in the library)
AND221
AND421
XOR221 ......
[benchmark] is the real test case we want to color
[benchmark] is in the format of standard cell rows
For each row, it specifies the sequence of different standard cells.
Eg: AND221  [left_x_coordinate]  [left_y_coordinate]. Using the offset of [left_x_coordinate]  [left_y_coordinate], we 
can get the actual positions of all the polygons within that standard cell.
Using cell-based and boundary condition to color the final chip.
-----------------------------------------------------------------------------------------------------------------------------------------*/
int main(int argc, char **argv){
	if(argc<6){
		cout<<"usage: ./tripple library_file benckmark_file  layer  distance sameFlag (whether VDD and GND are pre-assigned the same color)"<<endl;
		abort();
	}
	double totalTime, clockTime, thirdTime, forthTime;
	double begin, end;
	struct timeval tpstart, tpend;
	char libraryName[50], ftestName[50];
	int flag;
	gettimeofday(&tpstart,NULL);
	begin=clock();
	strcpy(libraryName,argv[1]);
	strcpy(ftestName,argv[2]);
	time_t t;
	struct tm * startTime, * endTime;
	int startHour, startMinute, startSecond, endHour, endSecond, endMinute;
	time(&t);
	startTime=localtime(&t);
	startHour=startTime->tm_hour;
	startMinute=startTime->tm_min;
	startSecond=startTime->tm_sec;

	LAYER=atoi(argv[3]);
	DISTANCE=atoi(argv[4]);
	flag=atoi(argv[5]);
	readLibFile(libraryName);
//	tripleColor(ftestName,flag);
	
	end=clock();
	time(&t);
	endTime=localtime(&t);
	endHour=endTime->tm_hour;
	endMinute=endTime->tm_min;
	endSecond=endTime->tm_sec;
	forthTime=(startHour-endHour)*3600+(startMinute-endMinute)*60+(startSecond-endSecond);
	
	thirdTime=(endTime->tm_hour-startTime->tm_hour)*3600+(endTime->tm_min-startTime->tm_min)*60+(endTime->tm_sec-startTime->tm_sec);
	
	clockTime=(double)(end-begin)/CLOCKS_PER_SEC;
	gettimeofday(&tpend,NULL);
	totalTime=1000000*(tpend.tv_sec-tpstart.tv_sec)+tpend.tv_usec-tpstart.tv_usec;
	totalTime/=1000000;
	printf("Total running time is %fs, %fs, %fs, %fs \n",totalTime,clockTime,thirdTime,forthTime);
	printf("start time: %d:%d:%d, end time %d:%d:%d\n",startHour, startMinute, startSecond, endHour, endMinute,endSecond);
//	outputBalanceSolution();
//	outputSolution();
//	DrawOptimalGraph();
//	printf(" Ratio: 1: %f : %f \n Random ration: 1: %f : %f \nTotal stitch number %d\n", area[1]/area[0], area[2]/area[0], areaRandom[1]/areaRandom[0], areaRandom[2]/areaRandom[0],totalStitchNum);
	return 1;
}
