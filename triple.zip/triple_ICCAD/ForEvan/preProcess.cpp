#include "preProcess.h"
#include <vector>
#include <cstring>
#include <map>
#include <set>
#include <queue>
#include <math.h>
#include <iostream>
#include <stdlib.h>
using namespace std;

#define MAXIMUM   99999999
#define MINIMUM   -99999999
#define BUFFERSIZE 251
#define STITCHDIS   400
map<string, standardCell *> cellLib;

extern void checkCellInLib();

bool comp(polygon*a, polygon*b) {
	return a->leftB < b->leftB ? 1 : ((a->leftB == b->leftB) && (a->upB > b->upB)) ? 1 : 0;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Calculate the edge area of one polygon
 -----------------------------------------------------------------------------------------------------------------------------------------*/
int calPolygonArea(polygon * curr){
	int **dividePlane, **centerX, **centerY, area=0;  // edges of the polyogn divide the plane into several pieces, which can be represented by a matrix
	char **planeFlag;  // denote whether the rectangle is whthin the polygon
	int rowX, rowY,i,j;
	set<int> xCoord, yCoord;
	set<int>::iterator xCoordIT, yCoordIT;
	vector< pair<int,int> >::iterator vertXYCoordIT;
	for(vertXYCoordIT=curr->vertXYCoord.begin();vertXYCoordIT!=curr->vertXYCoord.end();vertXYCoordIT++){
//		printf(" <%d  %d >  ",vertXYCoordIT->first,vertXYCoordIT->second);
		xCoord.insert(vertXYCoordIT->first);
		yCoord.insert(vertXYCoordIT->second);
	}
	rowX=yCoord.size()-1;
	rowY=xCoord.size()-1;
	dividePlane=(int **) malloc(sizeof(int *) * rowX);
	centerX=(int **) malloc(sizeof(int *) * rowX);
	centerY=(int **) malloc(sizeof(int *) * rowX);
	planeFlag=(char **) malloc(sizeof(char *) * rowX);
	for(i=0;i<rowX;i++){
		dividePlane[i]=(int *) malloc(sizeof(int ) * rowY);
		centerX[i]=(int *) malloc(sizeof(int ) * rowY);
		centerY[i]=(int *) malloc(sizeof(int ) * rowY);
		planeFlag[i]=(char *) malloc( sizeof(char ) * rowY);
	}
	i=0;
	j=0;
	int preX, preY, currX, currY;
	yCoordIT=yCoord.begin();	
	preY=*yCoordIT;
	yCoordIT++;
	for(;yCoordIT!=yCoord.end();yCoordIT++,i++){
		currY=*yCoordIT;
		xCoordIT=xCoord.begin();
		preX=*xCoordIT;
		xCoordIT++;
		j=0;
		for(;xCoordIT!=xCoord.end();xCoordIT++,j++){
			currX=*xCoordIT;
			centerX[i][j]=(preX+currX)/2;
			centerY[i][j]=(preY+currY)/2;			
			dividePlane[i][j]=abs((preX-currX)*(preY-currY));
			preX=currX;
//			printf("centerX[%d][%d]=%d,centerY[%d][%d]=%d,dividePlane[%d][%d]=%d\n",i,j,centerX[i][j],i,j,centerY[i][j],i,j,dividePlane[i][j]);
		}
		preY=currY;
	}	
	for(i=0;i<rowX;i++){
		for(j=0;j<rowY;j++)
			planeFlag[i][j]=false;
	}
	
	int degree=0, prePlane=1, currPlane=1;  // totally four planes,1,2,3,4 
	// if for a rectangle, the total degree is 360, it is within the polygon and contribute to the total area of the polygon
	for(i=0;i<rowX;i++){
		for(j=0;j<rowY;j++){
			degree=0;
			prePlane=1;
			currPlane=1;
			vertXYCoordIT=curr->vertXYCoord.begin();
			if(vertXYCoordIT->first < centerX[i][j] && vertXYCoordIT->second < centerY[i][j])
				currPlane=1;
			else if(vertXYCoordIT->first > centerX[i][j] && vertXYCoordIT->second < centerY[i][j])
				currPlane=2;
			else if(vertXYCoordIT->first > centerX[i][j] && vertXYCoordIT->second > centerY[i][j])
				currPlane=3;
			else if(vertXYCoordIT->first < centerX[i][j] && vertXYCoordIT->second > centerY[i][j])
				currPlane=4;
			prePlane=currPlane;
			vertXYCoordIT++;
			for(;vertXYCoordIT!=curr->vertXYCoord.end();vertXYCoordIT++){
				if(vertXYCoordIT->first < centerX[i][j] && vertXYCoordIT->second < centerY[i][j])
					currPlane=1;
				else if(vertXYCoordIT->first > centerX[i][j] && vertXYCoordIT->second < centerY[i][j])
					currPlane=2;
				else if(vertXYCoordIT->first > centerX[i][j] && vertXYCoordIT->second > centerY[i][j])
					currPlane=3;
				else if(vertXYCoordIT->first < centerX[i][j] && vertXYCoordIT->second > centerY[i][j])
					currPlane=4;
				if(prePlane==4 && currPlane==1)
					degree+=90;
				else if(prePlane==1 && currPlane==4)
					degree-=90;
				else degree+=90*(currPlane-prePlane);				
//				printf("prePlane=%d, currPlane=%d, degree=%d\n",prePlane,currPlane,degree);
				prePlane=currPlane;
			}
//			printf("\n");
			if(degree==360)
				planeFlag[i][j]=true;
		}
	}	
	for(i=0;i<rowX;i++){
		for(j=0;j<rowY;j++){
			if(planeFlag[i][j])
				area+=dividePlane[i][j];
		}
	}
//	printf("area=%d  rowX=%d  rowY=%d\n",area, rowX, rowY);
	// free all memory
	for(int i=0;i<rowX;i++){
		free(dividePlane[i]);
		free(centerX[i]);
		free(centerY[i]);
		free(planeFlag[i]);
	}
	free(dividePlane);	
	free(centerX);	
	free(centerY);	
	free(planeFlag);	
	return area;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Read the standard cell library. 
-----------------------------------------------------------------------------------------------------------------------------------------*/
void readLibFile(char *ftestname) {
	FILE * lib;
	vector < string > libName;
	vector<string>::iterator libNameIT;

	char testName[51], cellName[25];
	if ((lib = fopen(ftestname, "r")) == NULL) {
		cout << "In readLibFile, Cannot open file " << ftestname << endl;
		abort();
	}
	while (!feof(lib)) {
		if (fgets(testName, 50, lib) != NULL) { //for a standard cell in the library
			sscanf(testName,"%*s%s",cellName);
			libName.push_back(cellName);
		}
	}
	fclose(lib);
	testName[0]=0;
	FILE *fp;
	for (libNameIT = libName.begin(); libNameIT != libName.end(); libNameIT++) {
		strcpy(testName, "./cellLibrary/");
		strcat(testName,(*libNameIT).c_str());
//		testName[(*libNameIT).size()-1]=0;
		strcat(testName,".gds.txt");
		if ((fp = fopen(testName, "r")) == NULL) {
			cout << "Cannot open file " << testName << endl;
			abort();
		}
		char buf[BUFFERSIZE], word[50], cellName[50];
		int xCoord[4], yCoord[4], numCoord;
		int layer, leftB = MAXIMUM, rightB = 0, upB=MINIMUM;
		int cellLeftB = MAXIMUM, cellRightB = 0;
		standardCell *tempCell;
		while (!feof(fp)) {
			if (fgets(buf, 250, fp) != NULL) {
				sscanf(buf, "%s", word);
				if (strcmp(word, "strname") == 0) {
					sscanf(buf, "%*s \"%[0-9a-zA-Z_]", cellName);
					tempCell = new standardCell(0, cellName);
					cellLib.insert(	pair<string, standardCell *>(cellName, tempCell));
					break;
				}
			}
		}

		
		while (!feof(fp)) {
			if (fgets(buf, 250, fp) != NULL) {
				sscanf(buf, "%s", word);
				if (strcmp(word, "boundary") == 0) {
					fgets(buf, 250, fp);
					sscanf(buf, "%*s%d", &layer);
					if (layer != LAYER)
						continue;
					fgets(buf, 250, fp);
					fgets(buf, 250, fp);
					sscanf(buf, "%*s%d", &numCoord); //in every line, there are at most 4 pairs of coordinates			
					

					polygon * temp = new polygon(numCoord);
					tempCell->polygons.push_back(temp);
					tempCell->numPloygon += 1;

					sscanf(buf, "%*s%*d%d%d%d%d%d%d%d%d", &xCoord[0],
							&yCoord[0], &xCoord[1], &yCoord[1], &xCoord[2],
							&yCoord[2], &xCoord[3], &yCoord[3]);
					for (int i = 0; i < 4; i++) {
						if (leftB > xCoord[i])
							leftB = xCoord[i];
						if (rightB < xCoord[i])
							rightB = xCoord[i];
						if (cellLeftB > xCoord[i])
							cellLeftB = xCoord[i];
						if (cellRightB < xCoord[i])
							cellRightB = xCoord[i];
						if(upB<yCoord[i])
							upB=yCoord[i];
						temp->vertXYCoord.push_back(pair<int, int>(xCoord[i], yCoord[i]));
					}

					for (int i = 0; i < numCoord / 4-1; i++) {
						fgets(buf, 250, fp);
						sscanf(buf, "%d%d%d%d%d%d%d%d", &xCoord[0], &yCoord[0],
								&xCoord[1], &yCoord[1], &xCoord[2], &yCoord[2],
								&xCoord[3], &yCoord[3]);
						for (int i = 0; i < 4; i++) {
							if (leftB > xCoord[i])
								leftB = xCoord[i];
							if (rightB < xCoord[i])
								rightB = xCoord[i];

							if (cellLeftB > xCoord[i])
								cellLeftB = xCoord[i];
							if (cellRightB < xCoord[i])
								cellRightB = xCoord[i];

							temp->vertXYCoord.push_back(
									pair<int, int>(xCoord[i], yCoord[i]));
						}
					}
					fgets(buf, 250, fp);
					sscanf(buf, "%d%d%d%d%d%d%d%d", &xCoord[0], &yCoord[0],&xCoord[1], &yCoord[1], &xCoord[2], &yCoord[2],&xCoord[3], &yCoord[3]);
					for(int i=0;i<numCoord-numCoord/4*4;i++)
						temp->vertXYCoord.push_back(pair<int, int>(xCoord[i], yCoord[i]));
//					temp->vertXYCoord.push_back(temp->vertXYCoord.front()); //store the first pair of coordinates
					temp->leftB = leftB;
					temp->rightB = rightB;
					temp->upB=upB;
					temp->area=calPolygonArea(temp);
					
					leftB = MAXIMUM;
					rightB = MINIMUM;
					upB=MINIMUM;
				}
			} // end 	if(fgets(buf,250,fp)!=NULL){
		} //end while
		tempCell->leftB = cellLeftB;
		tempCell->rightB = cellRightB;
		sort(tempCell->polygons.begin(), tempCell->polygons.end(), comp);
		vector<polygon *>::iterator polygonIT;
		vector<pair<int, int> >::iterator vertXYCoordIT;
		int i = 0;
//		printf("Cell %s, polygons is %d\n",tempCell->name,tempCell->polygons.size());
		for (polygonIT = tempCell->polygons.begin();polygonIT != tempCell->polygons.end(); polygonIT++, i++) { //store polygon's index
			(*polygonIT)->index = i;
			(*polygonIT)->parentID = i;
//			printf("Polygon ID is %d, number of nodes is %d, left boundary is %d,  upB is %d,  area is %d\n",i, (*polygonIT)->vertXYCoord.size(), (*polygonIT)->leftB, (*polygonIT)->upB, (*polygonIT)->area);
//			for (vertXYCoordIT = (*polygonIT)->vertXYCoord.begin();vertXYCoordIT != (*polygonIT)->vertXYCoord.end();vertXYCoordIT++) {
//				printf("   %d %d   ", vertXYCoordIT->first,	vertXYCoordIT->second);
//			}
//			printf("\n");
		}
		fclose(fp);
	}
//	checkCellInLib();
}
polygon::polygon() 
:numVertix(-1), leftB(MAXIMUM), rightB(0), upB(MINIMUM), virtualRight(0), index(-1), area(0),parentID(-1) {
}
polygon::polygon(int num) 
:numVertix(num), leftB(MAXIMUM), rightB(0), upB(MINIMUM), virtualRight(0), index(-1), area(0),parentID(-1) {
}

polygon::polygon(int num,int left,int right,int up, int virtualR, int ID, int parent) :
		numVertix(num), leftB(left), rightB(right), upB(up),virtualRight(virtualR), index(ID), area(0),parentID(parent) {
}

polygon::polygon(polygon *& a){
	numVertix=a->numVertix;
	leftB=a->leftB;
	rightB=a->rightB;
	upB=a->upB;
	virtualRight=a->virtualRight;
	index=a->index;
	area=a->area;
	parentID=a->parentID;
	vertXYCoord=a->vertXYCoord;
	conflictEdge=a->conflictEdge;
	constraintID=a->constraintID;
	connectID=a->connectID;
}


/*-----------------------------------------------------------------------------------------------------------------------------------------
Check the coordinates of the polygons, for debug
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void checkPolygonCoord(polygon * currP){
	vector< pair<int,int> >::iterator vertXYCoordIT;
	int i=1;
	printf("Total number of coords is %d, index=%d\n",currP->vertXYCoord.size(),currP->index);
	for(vertXYCoordIT=currP->vertXYCoord.begin();vertXYCoordIT!=currP->vertXYCoord.end();vertXYCoordIT++,i++){
		printf("(%d   %d)  ",vertXYCoordIT->first,vertXYCoordIT->second);
		if(!(i%10))
			printf("\n");
	}
	printf("\n");
	if(currP->vertXYCoord.size()<5){
		printf("For current polygon, the number of coordinates are less than 5!\n");
		abort();
	}
}
/*-----------------------------------------------------------------------------------------------------------------------------------------
Check the color assignment of a node, for debug
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void checkNode(node * currNode){
	map<int, char>::iterator cutlineIT;
	int i(1);
	for(cutlineIT=currNode->cutline.begin();cutlineIT!=currNode->cutline.end();cutlineIT++,i++){
		printf("<%d  %d>  ",cutlineIT->first, cutlineIT->second);
		if(!(i%10))
			printf("\n");
	}
	printf("\n");
}
/*-----------------------------------------------------------------------------------------------------------------------------------------
 Decompose the polygon into several rectangles
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void polygon::decomposeRec() {
}

void rotateXYCoord(edge *&  thisEdge, edge *&  thatEdge){
	int tmp;
	// rotate x and y coordinates
	// the same method with orthogonalXEdge
	tmp=thisEdge->thisX;
	thisEdge->thisX=thisEdge->thisY;
	thisEdge->thisY=tmp;
	
	tmp=thisEdge->thatX;
	thisEdge->thatX=thisEdge->thatY;
	thisEdge->thatY=tmp;
	
	tmp=thatEdge->thisX;
	thatEdge->thisX=thatEdge->thisY;
	thatEdge->thisY=tmp;
	
	tmp=thatEdge->thatX;
	thatEdge->thatX=thatEdge->thatY;
	thatEdge->thatY=tmp;	
}
/*-----------------------------------------------------------------------------------------------------------------------------------------
 For debug
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void displayConflictEdge(edge *curr, edge * thisEdge){
//	printf(" conflicting edge is: (%d  %d)(%d  %d)\n",curr->thisX,curr->thisY, curr->thatX, curr->thatY);
	if(curr->thisX==thisEdge->thisX && curr->thatX==thisEdge->thatX && curr->thatX==thisEdge->thisX){
		if((!WITHIN(thisEdge->thisY, thisEdge->thatY,curr->thisY)) || (!WITHIN(thisEdge->thisY, thisEdge->thatY,curr->thatY))){
			printf("The constraint edge is not within the segment!\n");
			abort();
		}
	}
	else if(curr->thisY==thisEdge->thisY && curr->thatY==thisEdge->thatY && curr->thatY==thisEdge->thisY){
		if((!WITHIN(thisEdge->thisX, thisEdge->thatX,curr->thisX)) || (!WITHIN(thisEdge->thisX, thisEdge->thatX,curr->thatX))){
			printf("1The constraint edge is not within the segment!\n");
			abort();
		}
	}
	else{
		printf("The edge is diagonal!\n");
		abort();
	}

}
/*-----------------------------------------------------------------------------------------------------------------------------------------
 For orthogonal Y edges
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void polygon::orthogonalYEdge(edge *& thisEdge, edge *& thatEdge, int thatPolygonIndex){
	int thisX, thisY, thatX, thatY, thisNearX, thisNearY,thatNearX, thatNearY;
	int conflictDis;
	rotateXYCoord(thisEdge,thatEdge);

	//       |
	//       |
	//       |
	// ----------------
	// two edges like the above
	if(WITHIN(thisEdge->thisX, thisEdge->thatX,thatEdge->thisX)){
		if(abs(thisEdge->thisY-thatEdge->thisY) > abs(thisEdge->thisY-thatEdge->thatY)){
			thatNearX=thatEdge->thatX;
			thatNearY=thatEdge->thatY;
		}
		else {
			thatNearX=thatEdge->thisX;
			thatNearY=thatEdge->thisY;
		}
		if(abs(thisEdge->thisY-thatNearY)>DISTANCE){
			rotateXYCoord(thisEdge,thatEdge);
			return;
		}
		conflictDis=(int)sqrt(DISTANCE*DISTANCE-fabs(thisEdge->thisY-thatNearY)*fabs(thisEdge->thisY-thatNearY));
		if(thatNearX-conflictDis>=thisEdge->thisX){
			thisX=thatNearX-conflictDis;
			thisY=thisEdge->thisY;
		}
		else{
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
		}

		if(thatNearX+conflictDis<=thisEdge->thatX){
			thatX=thatNearX+conflictDis;
			thatY=thisEdge->thatY;
		}
		else{
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
	}
	//                 |
	//  ----------     |
	//                 |
	// two edges like the above
	else if(WITHIN(thatEdge->thisY, thatEdge->thatY,thisEdge->thisY)){
		if(abs(thisEdge->thisX-thatEdge->thisX) > abs(thisEdge->thatX-thatEdge->thisX)){
			thisNearX=thisEdge->thatX;
			thisNearY=thisEdge->thatY;
		}
		else {
			thisNearX=thisEdge->thisX;
			thisNearY=thisEdge->thisY;
		}
		if(abs(thisNearX-thatEdge->thisX) > DISTANCE){
			rotateXYCoord(thisEdge,thatEdge);
			return;
		}
		conflictDis=DISTANCE-abs(thisNearX-thatEdge->thisX);
		if(thisNearX<thatEdge->thisX){  // thisEdge is to the left of thatEdge
			if(thisEdge->thatX-conflictDis>=thisEdge->thisX){
				thisX=thisEdge->thatX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else{
			if(thisEdge->thisX+conflictDis<=thisEdge->thatX){
				thatX=thisEdge->thisX+conflictDis;
				thatY=thisEdge->thisY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
		}
	}
	//                 |
	//                 |
	//                 |
	//
	//  -----------
	// two edges like the above
	else if((!WITHIN(thisEdge->thisX, thisEdge->thatX,thatEdge->thisX)) && (!WITHIN(thatEdge->thisY, thatEdge->thatY,thisEdge->thisY))){
		// find the nearest points
		if(abs(thatEdge->thisX-thisEdge->thisX) + abs(thatEdge->thisY-thisEdge->thisY) > abs(thatEdge->thatX-thisEdge->thisX) + abs(thatEdge->thatY-thisEdge->thisY)){
			thatNearX=thatEdge->thatX;
			thatNearY=thatEdge->thatY;
		}
		else {
			thatNearX=thatEdge->thisX;
			thatNearY=thatEdge->thisY;
		}
		if(abs(thisEdge->thisX-thatEdge->thisX) + abs(thisEdge->thisY-thatEdge->thisY) > abs(thisEdge->thatX-thatEdge->thisX) + abs(thisEdge->thatY-thatEdge->thisY)){
			thisNearX=thisEdge->thatX;
			thisNearY=thisEdge->thatY;
		}
		else{
			thisNearX=thisEdge->thisX;
			thisNearY=thisEdge->thisY;
		} // find nearest point done!
		if(sqrt(fabs(thisNearX-thatNearX)*fabs(thisNearX-thatNearX) + fabs(thisNearY-thatNearY)*fabs(thisNearY-thatNearY))>DISTANCE){
			rotateXYCoord(thisEdge,thatEdge);
			return;
		}
		conflictDis=(int)sqrt(DISTANCE*DISTANCE-fabs(thatNearY-thisNearY)*fabs(thatNearY-thisNearY));
		conflictDis-=abs(thisNearX-thatNearX);
		// thisEdge is to the left of thatEdge
		if(thisEdge->thisX<thatEdge->thisX){
			if(thisEdge->thatX-conflictDis>=thisEdge->thisX){
				thisX=thisEdge->thatX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else{
			if(thisEdge->thisX+conflictDis<=thisEdge->thatX){
				thatX=thisEdge->thisX+conflictDis;
				thatY=thisEdge->thatY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
		}
	}
	else {
		printf("In preProcess.cpp, void polygon::orthogonalYEdge(edge &* thisEdge, edge &* thatEdge), no such cases!\n");
		abort();
	}

	edge * conEdge= new edge;
	conEdge->thisX=thisY;
	conEdge->thisY=thisX;
	conEdge->thatX=thatY;
	conEdge->thatY=thatX;
	conEdge->index=thatPolygonIndex;
	conflictEdge.push_back(conEdge);

	rotateXYCoord(thisEdge,thatEdge);
	displayConflictEdge(conEdge,thisEdge);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 For orthogonal X edges
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void polygon::orthogonalXEdge(edge *& thisEdge, edge *& thatEdge, int thatPolygonIndex){
	int thisX, thisY, thatX, thatY, thisNearX, thisNearY,thatNearX, thatNearY;
	int conflictDis;
	//       |
	//       |
	//       |
	// ----------------
	// two edges like the above
	if(WITHIN(thisEdge->thisX, thisEdge->thatX,thatEdge->thisX)){
		if(abs(thisEdge->thisY-thatEdge->thisY) > abs(thisEdge->thisY-thatEdge->thatY)){
			thatNearX=thatEdge->thatX;
			thatNearY=thatEdge->thatY;
		}
		else {
			thatNearX=thatEdge->thisX;
			thatNearY=thatEdge->thisY;
		}
		if(abs(thisEdge->thisY-thatNearY)>DISTANCE)
			return;
		conflictDis=(int)sqrt(DISTANCE*DISTANCE-fabs(thisEdge->thisY-thatNearY)*fabs(thisEdge->thisY-thatNearY));
		if(thatNearX-conflictDis>=thisEdge->thisX){
			thisX=thatNearX-conflictDis;
			thisY=thisEdge->thisY;
		}
		else{
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
		}

		if(thatNearX+conflictDis<=thisEdge->thatX){
			thatX=thatNearX+conflictDis;
			thatY=thisEdge->thatY;
		}
		else{
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
	}
	//                 |
	//  ----------     |
	//                 |
	// two edges like the above
	else if(WITHIN(thatEdge->thisY, thatEdge->thatY,thisEdge->thisY)){
		if(abs(thisEdge->thisX-thatEdge->thisX) > abs(thisEdge->thatX-thatEdge->thisX)){
			thisNearX=thisEdge->thatX;
			thisNearY=thisEdge->thatY;
		}
		else {
			thisNearX=thisEdge->thisX;
			thisNearY=thisEdge->thisY;
		}
		if(abs(thisNearX-thatEdge->thisX) > DISTANCE)
			return;
		conflictDis=DISTANCE-abs(thisNearX-thatEdge->thisX);
		if(thisNearX<thatEdge->thisX){  // thisEdge is to the left of thatEdge
			if(thisEdge->thatX-conflictDis>=thisEdge->thisX){
				thisX=thisEdge->thatX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else{
			if(thisEdge->thisX+conflictDis<=thisEdge->thatX){
				thatX=thisEdge->thisX+conflictDis;
				thatY=thisEdge->thisY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
		}
	}
	//                 |
	//                 |
	//                 |
	//
	//  -----------
	// two edges like the above
	else if((!WITHIN(thisEdge->thisX, thisEdge->thatX,thatEdge->thisX)) && (!WITHIN(thatEdge->thisY, thatEdge->thatY,thisEdge->thisY))){
		// find the nearest points
		if(abs(thatEdge->thisX-thisEdge->thisX) + abs(thatEdge->thisY-thisEdge->thisY) > abs(thatEdge->thatX-thisEdge->thisX) + abs(thatEdge->thatY-thisEdge->thisY)){
			thatNearX=thatEdge->thatX;
			thatNearY=thatEdge->thatY;
		}
		else {
			thatNearX=thatEdge->thisX;
			thatNearY=thatEdge->thisY;
		}
		if(abs(thisEdge->thisX-thatEdge->thisX) + abs(thisEdge->thisY-thatEdge->thisY) > abs(thisEdge->thatX-thatEdge->thisX) + abs(thisEdge->thatY-thatEdge->thisY)){
			thisNearX=thisEdge->thatX;
			thisNearY=thisEdge->thatY;
		}
		else{
			thisNearX=thisEdge->thisX;
			thisNearY=thisEdge->thisY;
		} // find nearest point done!
		if(sqrt(abs(thisNearX-thatNearX)*abs(thisNearX-thatNearX) + abs(thisNearY-thatNearY)*abs(thisNearY-thatNearY))>DISTANCE)
			return;
		conflictDis=(int)sqrt(DISTANCE*DISTANCE-fabs(thatNearY-thisNearY)*fabs(thatNearY-thisNearY));
		conflictDis-=abs(thisNearX-thatNearX);
		// thisEdge is to the left of thatEdge
		if(thisEdge->thisX<thatEdge->thisX){
			if(thisEdge->thatX-conflictDis>=thisEdge->thisX){
				thisX=thisEdge->thatX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else{
			if(thisEdge->thisX+conflictDis<=thisEdge->thatX){
				thatX=thisEdge->thisX+conflictDis;
				thatY=thisEdge->thatY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
		}
	}
	else {
		printf("In preProcess.cpp, void polygon::orthogonalXEdge(edge &* thisEdge, edge &* thatEdge), no such cases!\n");
		abort();
	}
	edge * conEdge= new edge;
	conEdge->thisX=thisX;
	conEdge->thisY=thisY;
	conEdge->thatX=thatX;
	conEdge->thatY=thatY;
	conEdge->index=thatPolygonIndex;
	conflictEdge.push_back(conEdge);
	displayConflictEdge(conEdge,thisEdge);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 For parallel Y edges
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void polygon::parallelYEdge(edge *& thisEdge, edge *& thatEdge, int thatPolygonIndex){
	if(abs(thisEdge->thisX-thatEdge->thatX)>DISTANCE)
		return;
	int thisX, thisY, thatX, thatY, thisNearX, thisNearY,thatNearX, thatNearY;
	rotateXYCoord(thisEdge,thatEdge);


	// if the two edges are like this
	//  ---------
	//                -----------
	// horizontal but their projection do not overlap
	// we should find the nearest two points of these two edges
	if((!WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thisX)) && (!WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thatX))
			&& (!WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thisX)) && (!WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thatX))){
		if(abs(thatEdge->thisX-thisEdge->thisX) + abs(thatEdge->thisY-thisEdge->thisY) > abs(thatEdge->thisX-thisEdge->thatX) + abs(thatEdge->thisY-thisEdge->thatY)){
			thisNearX=thisEdge->thatX;
			thisNearY=thisEdge->thatY;
		}
		else {
			thisNearX=thisEdge->thisX;
			thisNearY=thisEdge->thisY;
		}
		if(abs(thisEdge->thisX-thatEdge->thisX) + abs(thisEdge->thisY-thatEdge->thisY) > abs(thisEdge->thisX- thatEdge->thatX) + abs(thisEdge->thisY- thatEdge->thatY)){
			thatNearX=thatEdge->thatX;
			thatNearY=thatEdge->thatY;
		}
		else {
			thatNearX=thatEdge->thisX;
			thatNearY=thatEdge->thisY;
		}
		// nearest points found! which are stored in thisNearX, thisNearY, thatNearX, thatNearY
		// larger than DISTANCE
		if(sqrt(abs(thisNearX-thatNearX)*abs(thisNearX-thatNearX) + abs(thisNearY-thatNearY)*abs(thisNearY-thatNearY)) > DISTANCE){
			rotateXYCoord(thisEdge,thatEdge);
			return;
		}
		else {
			int conflictDis=(int)sqrt( DISTANCE*DISTANCE - (double)(thatNearY- thisNearY)*(thatNearY- thisNearY));
			conflictDis-=abs(thisNearX-thatNearX);
			// thisEdge is on the left of thatEdge
			if(thisEdge->thisX < thatNearX ){
				if(thisEdge->thisX<=(thisEdge->thatX-conflictDis)){
					thisX=thisEdge->thatX-conflictDis;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thatX;
					thatY=thisEdge->thatY;
				}
				else {
					thisX=thisEdge->thisX;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thatX;
					thatY=thisEdge->thatY;
				}
			}
			// thisEdge is on the right of thatEdge
			else {
				if(thisEdge->thisX+conflictDis<=thisEdge->thatX){
					thisX=thisEdge->thisX;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thisX+conflictDis;
					thatY=thisEdge->thatY;
				}
				else{
					thisX=thisEdge->thisX;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thatX;
					thatY=thisEdge->thatY;
				}
			}
		}
	}
	// if the two edges are like this
	//  ---------
	//      ------------
	// horizontal and their projections overlap
	//
	else if(((WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thisX)) && (!WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thatX)))
			|| ((WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thisX)) && (!WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thatX)))){
		int conflictDis=(int) sqrt(DISTANCE*DISTANCE-(double)(thisEdge->thisY-thatEdge->thisY)*(thisEdge->thisY-thatEdge->thisY));
		//thisEdge is to the left of thatEdge
		if(thisEdge->thisX<thatEdge->thisX){
			if(thatEdge->thisX-conflictDis>=thisEdge->thisX){
				thisX=thatEdge->thisX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}

			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else{
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
			if(thatEdge->thatX+conflictDis < thisEdge->thatX){
				thatX=thatEdge->thatX+conflictDis;
				thatY=thisEdge->thatY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
		}
	}
	// if the two edges are like this
	//          ---------
	//      ------------------
	// one is contained in another
	//
	else if (((WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thisX)) && (WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thatX)))
			|| ((WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thisX)) && (WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thatX)))){
		if(thisEdge->thisX>=thatEdge->thisX && thisEdge->thatX<=thatEdge->thatX){
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else {
			int conflictDis=(int) sqrt(DISTANCE*DISTANCE-(double)(thisEdge->thisY-thatEdge->thisY)*(thisEdge->thisY-thatEdge->thisY));
			if(thatEdge->thisX-conflictDis>=thisEdge->thisX){
				thisX=thatEdge->thisX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}
			if(thatEdge->thatX+conflictDis<=thisEdge->thatX){
				thatX=thatEdge->thatX+conflictDis;
				thatY=thisEdge->thatY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
		}
	}
	else{
		printf("In preProcess.cpp, void polygon::parallelYEdge(edge &* thisEdge, edge &* thatEdge), no such cases!\n");
		abort();
	}

	edge * conEdge= new edge;
	conEdge->thisX=thisY;
	conEdge->thisY=thisX;
	conEdge->thatX=thatY;
	conEdge->thatY=thatX;
	conEdge->index=thatPolygonIndex;
	conflictEdge.push_back(conEdge);

	rotateXYCoord(thisEdge,thatEdge);
	displayConflictEdge(conEdge,thisEdge);
}
/*-----------------------------------------------------------------------------------------------------------------------------------------
 For parallel X edges
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void polygon::parallelXEdge(edge *& thisEdge, edge *& thatEdge, int thatPolygonIndex){
	if(abs(thisEdge->thisY-thatEdge->thatY)>DISTANCE)
		return;
	int thisX, thisY, thatX, thatY, thisNearX, thisNearY,thatNearX, thatNearY;
	// if the two edges are like this
	//  ---------
	//                -----------
	// horizontal but their projection do not overlap
	// we should find the nearest two points of these two edges
	if((!WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thisX)) && (!WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thatX))
			&& (!WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thisX)) && (!WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thatX))){
		if(abs(thatEdge->thisX-thisEdge->thisX) + abs(thatEdge->thisY-thisEdge->thisY) > abs(thatEdge->thisX-thisEdge->thatX) + abs(thatEdge->thisY-thisEdge->thatY)){
			thisNearX=thisEdge->thatX;
			thisNearY=thisEdge->thatY;
		}
		else {
			thisNearX=thisEdge->thisX;
			thisNearY=thisEdge->thisY;
		}
		if(abs(thisEdge->thisX-thatEdge->thisX) + abs(thisEdge->thisY-thatEdge->thisY) > abs(thisEdge->thisX- thatEdge->thatX) + abs(thisEdge->thisY- thatEdge->thatY)){
			thatNearX=thatEdge->thatX;
			thatNearY=thatEdge->thatY;
		}
		else {
			thatNearX=thatEdge->thisX;
			thatNearY=thatEdge->thisY;
		}
		// nearest points found! which are stored in thisNearX, thisNearY, thatNearX, thatNearY
		// larger than DISTANCE
		if(sqrt(fabs(thisNearX-thatNearX)*fabs(thisNearX-thatNearX) + fabs(thisNearY-thatNearY)*fabs(thisNearY-thatNearY)) > DISTANCE)
			return;
		else {
			int conflictDis=(int)sqrt( DISTANCE*DISTANCE - (double)(thatNearY- thisNearY)*(thatNearY- thisNearY));
			conflictDis-=abs(thisNearX-thatNearX);
			// thisEdge is on the left of thatEdge
			if(thisEdge->thisX < thatNearX ){
				if(thisEdge->thisX<=(thisEdge->thatX-conflictDis)){
					thisX=thisEdge->thatX-conflictDis;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thatX;
					thatY=thisEdge->thatY;
				}
				else {
					thisX=thisEdge->thisX;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thatX;
					thatY=thisEdge->thatY;
				}
			}
			// thisEdge is on the right of thatEdge
			else {
				if(thisEdge->thisX+conflictDis<=thisEdge->thatX){
					thisX=thisEdge->thisX;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thisX+conflictDis;
					thatY=thisEdge->thatY;
				}
				else{
					thisX=thisEdge->thisX;
					thisY=thisEdge->thisY;
					thatX=thisEdge->thatX;
					thatY=thisEdge->thatY;
				}
			}
		}
	}
	// if the two edges are like this
	//  ---------
	//      ------------
	// horizontal and their projections overlap
	//
	else if(((WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thisX)) && (!WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thatX)))
			|| ((WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thisX)) && (!WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thatX)))){
		int conflictDis=(int) sqrt(DISTANCE*DISTANCE-(double)(thisEdge->thisY-thatEdge->thisY)*(thisEdge->thisY-thatEdge->thisY));
		//thisEdge is to the left of thatEdge
		if(thisEdge->thisX<thatEdge->thisX){
			if(thatEdge->thisX-conflictDis>=thisEdge->thisX){
				thisX=thatEdge->thisX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}

			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else{
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
			if(thatEdge->thatX+conflictDis < thisEdge->thatX){
				thatX=thatEdge->thatX+conflictDis;
				thatY=thisEdge->thatY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
		}
	}
	// if the two edges are like this
	//          ---------
	//      ------------------
	// one is contained in another
	//
	else if (((WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thisX)) && (WITHIN(thisEdge->thisX, thisEdge->thatX, thatEdge->thatX)))
			|| ((WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thisX)) && (WITHIN(thatEdge->thisX, thatEdge->thatX, thisEdge->thatX)))){
		if(thisEdge->thisX>=thatEdge->thisX && thisEdge->thatX<=thatEdge->thatX){
			thisX=thisEdge->thisX;
			thisY=thisEdge->thisY;
			thatX=thisEdge->thatX;
			thatY=thisEdge->thatY;
		}
		else {
			int conflictDis=(int) sqrt(DISTANCE*DISTANCE-(double)(thisEdge->thisY-thatEdge->thisY)*(thisEdge->thisY-thatEdge->thisY));
			if(thatEdge->thisX-conflictDis>=thisEdge->thisX){
				thisX=thatEdge->thisX-conflictDis;
				thisY=thisEdge->thisY;
			}
			else{
				thisX=thisEdge->thisX;
				thisY=thisEdge->thisY;
			}
			if(thatEdge->thatX+conflictDis<=thisEdge->thatX){
				thatX=thatEdge->thatX+conflictDis;
				thatY=thisEdge->thatY;
			}
			else{
				thatX=thisEdge->thatX;
				thatY=thisEdge->thatY;
			}
		}
	}
	else{
		printf("In preProcess.cpp, void polygon::parallelXEdge(edge &* thisEdge, edge &* thatEdge), no such cases!\n");
		abort();
	}
	edge * conEdge= new edge;
	conEdge->thisX=thisX;
	conEdge->thisY=thisY;
	conEdge->thatX=thatX;
	conEdge->thatY=thatY;
	conEdge->index=thatPolygonIndex;
	conflictEdge.push_back(conEdge);
	displayConflictEdge(conEdge,thisEdge);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
Given two edges, calculate their conflicting parts.
thisEdge belongs to this polygon, thatEdge belongs to other polygons.
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void polygon::geneConstraintEdge(edge *& thisEdge, edge *& thatEdge, int thatPolygonIndex ){
	int tmp;
	// coordinates from smaller to larger
	if(thisEdge->thisX==thisEdge->thatX){
		if(thisEdge->thisY>thisEdge->thatY){
			tmp=thisEdge->thisY;
			thisEdge->thisY=thisEdge->thatY;
			thisEdge->thatY=tmp;
		}
	}
	else{
		if(thisEdge->thisX>thisEdge->thatX){
			tmp=thisEdge->thisX;
			thisEdge->thisX=thisEdge->thatX;
			thisEdge->thatX=tmp;
		}
	}
	if(thatEdge->thisX==thatEdge->thatX){
		if(thatEdge->thisY>thatEdge->thatY){
			tmp=thatEdge->thisY;
			thatEdge->thisY=thatEdge->thatY;
			thatEdge->thatY=tmp;
		}
	}
	else{
		if(thatEdge->thisX>thatEdge->thatX){
			tmp=thatEdge->thisX;
			thatEdge->thisX=thatEdge->thatX;
			thatEdge->thatX=tmp;
		}
	}
//	printf("Now processing edge: (%d  %d) (%d  %d) and (%d  %d) (%d  %d)\n",thisEdge->thisX,thisEdge->thisY, thisEdge->thatX,thisEdge->thatY,
//			thatEdge->thisX, thatEdge->thisY, thatEdge->thatX, thatEdge->thatY);
	// thisEdge is horizontal
	if(thisEdge->thisY==thisEdge->thatY){
		//thatEdge is horizontal
		if(thatEdge->thisY==thatEdge->thatY){
//			printf("parallelXEdge\n");
			parallelXEdge(thisEdge,thatEdge,thatPolygonIndex);
		}
		// thatEdge is vertical
		else{
//			printf("orthogonalXEdge\n");
			orthogonalXEdge(thisEdge,thatEdge,thatPolygonIndex);
		}
	}
	// thisEdge is vertical
	else{
		//thatEdge is vertical
		if(thatEdge->thisX==thatEdge->thatX){
//			printf("parallelYEdge\n");
			parallelYEdge(thisEdge,thatEdge,thatPolygonIndex);
		}
		// thatEdge is horizontal
		else{
//			printf("orthogonalYEdge\n");
			orthogonalYEdge(thisEdge,thatEdge,thatPolygonIndex);
		}
	}
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Constructer
 -----------------------------------------------------------------------------------------------------------------------------------------*/
standardCell::standardCell(int num, char *cellName) :
		numPloygon(num), leftB(MAXIMUM), rightB(0)
//,leftBoundary(NULL)
//,rightBoundary(NULL)
				, headSame(NULL)
,headDiff(NULL){
	strcpy(name, cellName);
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Desstructer
 -----------------------------------------------------------------------------------------------------------------------------------------*/
standardCell::~standardCell() {
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 sort the polygons according to the increasing X coordinates
 -----------------------------------------------------------------------------------------------------------------------------------------*/
bool comp_ploygon(polygon *a, polygon *b) {
	return a->leftB < b->leftB;
}


/*-----------------------------------------------------------------------------------------------------------------------------------------
 Calculate the edge distance between one horizontal and one vertical lines
 a is horizontal and b is vertical
 -----------------------------------------------------------------------------------------------------------------------------------------*/
double calDisHV(edge *a, edge *b) {
	double dis, dis1, dis2;
	double thisX, thisY, thatX, thatY;
	if (WITHIN(b->thisY, b->thatY, a->thisY)) {
		dis1 = abs(b->thisX - a->thisX);
		dis2 = abs(b->thisX - a->thatX);
		dis = dis1 > dis2 ? dis2 : dis1;
	} else if (WITHIN(a->thisX, a->thatX, b->thisX)) {
		dis1 = abs(a->thisY - b->thisY);
		dis2 = abs(a->thisY - b->thatY);
		dis = dis1 > dis2 ? dis2 : dis1;
	} else {
		if (abs(a->thisX - b->thisX) + abs(a->thisY - b->thisY)	< abs(a->thatX - b->thisX) + abs(a->thatY - b->thisY)) { //find the nearer point in line a
			thisX = a->thisX;
			thisY = a->thisY;
		} else {
			thisX = a->thatX;
			thisY = a->thatY;
		}
		if (fabs(thisX - b->thisX) + fabs(thisY - b->thisY) < fabs(thisX - b->thatX) + fabs(thisY - b->thatY)) { //find the nearer point in line b
			thatX = b->thisX;
			thatY = b->thisY;
		} else {
			thatX = b->thatX;
			thatY = b->thatY;
		}
		dis = sqrt(	(thatX - thisX) * (thatX - thisX) + (thatY - thisY) * (thatY - thisY));
	}
	return dis;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Calculate the edge distance between two polygons
 -----------------------------------------------------------------------------------------------------------------------------------------*/
double standardCell::calEdgeDis(edge *a, edge * b) {
	double dis = 0, disA, disB;
	double thisX, thisY, thatX, thatY;
	bool aHorizontal = false, bHorizontal = false;
	if (a->thisY == a->thatY)
		aHorizontal = true;
	if (b->thisY == b->thatY)
		bHorizontal = true;

	if (aHorizontal && bHorizontal) { //all horizontal direction
		if (WITHIN(a->thisX, a->thatX, b->thisX) || WITHIN(a->thisX, a->thatX, b->thatX) 
				|| WITHIN(b->thisX, b->thatX, a->thisX)	|| WITHIN(b->thisX, b->thatX, a->thatX))
			dis = abs(a->thisY - b->thisY);
		else {
			if (abs(a->thisX - b->thisX) < abs(a->thatX - b->thatX)) { //find the nearer point in one line
				thisX = a->thisX;
				thisY = a->thisY;
			} else {
				thisX = a->thatX;
				thisY = a->thatY;
			}
			if (fabs(thisX - b->thisX) < fabs(thisX - b->thatX)) { //find the other nearer point in the other line
				thatX = b->thisX;
				thatY = b->thisY;
			} else {
				thatX = b->thatX;
				thatY = b->thatY;
			}
			dis = sqrt(	(thatX - thisX) * (thatX - thisX) + (thatY - thisY) * (thatY - thisY));
		}
	} else if (!aHorizontal && !bHorizontal) { //all vertical direction
		if (WITHIN(a->thisY, a->thatY, b->thisY)
				|| WITHIN(a->thisY, a->thatY, b->thatY)
				|| WITHIN(b->thisY, b->thatY, a->thisY)
				|| WITHIN(b->thisY, b->thatY, a->thatY))
			dis = abs(a->thisX - b->thisX);
		else {
			if (abs(a->thisY - b->thisY) < abs(a->thisY - b->thatY)) { //find the nearer point in one line
				thisX = a->thisX;
				thisY = a->thisY;
			} else {
				thisX = a->thatX;
				thisY = a->thatY;
			}
			if (fabs(thisY - b->thisY) < fabs(thisY - b->thatY)) { //find the other nearer point in the other line
				thatX = b->thisX;
				thatY = b->thisY;
			} else {
				thatX = b->thatX;
				thatY = b->thatY;
			}
			dis = sqrt(	(thatX - thisX) * (thatX - thisX) + (thatY - thisY) * (thatY - thisY));
		}
	} else { //one horizontal, one vertical
		if (aHorizontal)
			dis = calDisHV(a, b);
		else
			dis = calDisHV(b, a);
	}
	return dis;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Need a more accurate approach to calculated the minimum distance between two polygons
 We need to calculate the distance between edges and edges of the two pologons
 offsetA: X coordinate of polygon a in the chip
 offsetB: X coordinate of polygon b in the chip
 -----------------------------------------------------------------------------------------------------------------------------------------*/
double standardCell::calPolygonDis(polygon *a, int offsetA, polygon *b, int offsetB) {
	double dis = MAXIMUM, calDis;
	vector<pair<int, int> >::iterator cooraIT, cooraNextIT, coorbIT,coorbNextIT;
	cooraNextIT = a->vertXYCoord.begin();
	cooraNextIT++;
	edge front, back;
	for (cooraIT = a->vertXYCoord.begin(); cooraNextIT != a->vertXYCoord.end();	cooraIT++, cooraNextIT++) {
		coorbNextIT = b->vertXYCoord.begin();
		coorbNextIT++;
		front.thisX = cooraIT->first+offsetA;
		front.thisY = cooraIT->second;
		front.thatX = cooraNextIT->first+offsetA;
		front.thatY = cooraNextIT->second;
		for (coorbIT = b->vertXYCoord.begin();coorbNextIT != b->vertXYCoord.end(); coorbIT++, coorbNextIT++) {
			back.thisX = coorbIT->first+offsetB;
			back.thisY = coorbIT->second;
			back.thatX = coorbNextIT->first+offsetB;
			back.thatY = coorbNextIT->second;
			calDis = calEdgeDis(&front, &back);
//			printf("Now processing edge: front: (%d %d)  (%d %d),   back: (%d %d)  (%d %d), calDis=%f\n",front.thisX,front.thisY,front.thatX,front.thatY,back.thisX,back.thisY,back.thatX,back.thatY,calDis);
			if (dis > calDis)
				dis = calDis;
		}
	}
	return dis;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Check the ocnstrainted polygons for all the polygons within the standard cells
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void standardCell::checkConstraintP() {
	vector<polygon *>::iterator polygonIT;
	set<int>::iterator constraintIDIT;
	polygon* curr;
	printf("For cell %s\n",name);
	for (polygonIT = stitchPolygons.begin(); polygonIT != stitchPolygons.end();	polygonIT++) {
		curr = *polygonIT;
		printf("For polygon %d, its conflicting polygongs are ", curr->index);
		for (constraintIDIT = curr->constraintID.begin();
				constraintIDIT != curr->constraintID.end(); constraintIDIT++) {
			printf(" %d ", *constraintIDIT);
		}
		printf("\n");
	}
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Construct a constrain graph for the polygons within the standard cells
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void standardCell::constraintGraph(bool stitchPolygon) {
	sort(polygons.begin(), polygons.end(), comp_ploygon);
	vector<polygon *>::iterator polygonIT, nextIT;
	polygon * current, *next;
	double dis = 0;
	if(!stitchPolygon){
		for (polygonIT = polygons.begin(); polygonIT != polygons.end();	polygonIT++) {
			current = *polygonIT;
			nextIT = polygonIT;
			nextIT++;
			for (; nextIT != polygons.end(); nextIT++) {
				next = *nextIT;
				if (next->leftB - current->rightB <= DISTANCE) {
					dis = calPolygonDis(current,0, next,0);   //offset is set to be 0 initially
//				printf("distance between polygon %d and %d is %f\n",
//						current->index, next->index, dis);
					if (dis <= DISTANCE) { //if two polygons conflicts with each other
//						current->constraintP.insert(next);
						current->constraintID.insert(next->index);
						polygons[next->index]->constraintID.insert(current->index);
					}
				} else	break;
			}
		}
	}
	else{
		for (polygonIT = stitchPolygons.begin(); polygonIT != stitchPolygons.end();	polygonIT++) {
			current = *polygonIT;
			nextIT = polygonIT;
			nextIT++;
			for (; nextIT != stitchPolygons.end(); nextIT++) {				
				next = *nextIT;
				if(current->parentID==next->parentID)  // generated by the same parent polygon, we do not add conflicting edges
					continue;
				if (next->leftB - current->rightB <= DISTANCE) {
					dis = calPolygonDis(current,0, next,0);   //offset is set to be 0 initially
//					printf("distance between polygon %d and %d is %f\n",current->index, next->index, dis);
					if (dis <= DISTANCE) { //if two polygons conflicts with each other
						current->constraintID.insert(next->index);
						stitchPolygons[next->index]->constraintID.insert(current->index);
					}
				} else	break;
			}
		}
	}
//	checkConstraintP();
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Construct a constrain graph for the polygons within the standard cells
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void standardCell::virtualExtend() {
	vector<polygon *>::iterator polygonIT;
	int rightMost = MINIMUM;
	polygon * curr;
	for (polygonIT = stitchPolygons.begin(); polygonIT != stitchPolygons.end();	polygonIT++) {
		set<int>::iterator constraintIDIT;
		curr = *polygonIT;
		rightMost = curr->rightB;
		for (constraintIDIT = curr->constraintID.begin();constraintIDIT != curr->constraintID.end(); constraintIDIT++) {
			if (rightMost < stitchPolygons[*constraintIDIT]->leftB)
				rightMost = stitchPolygons[*constraintIDIT]->leftB;
		}
		curr->virtualRight = rightMost - 1; // 
//		printf("For polygon %d, virtual right is %d  cell name is %s  stitch polygons %d\n", curr->index,curr->virtualRight, name,stitchPolygons.size());
	}
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Check whether color assignment is legal
 -----------------------------------------------------------------------------------------------------------------------------------------*/
bool standardCell::checkLegal(int ID, treeNode *curr, char color) {
	treeNode *p = curr;
	while (p->color != -1) {
		if ((stitchPolygons[p->index]->constraintID.find(ID)!= stitchPolygons[p->index]->constraintID.end() && p->color != color)
				|| stitchPolygons[p->index]->constraintID.find(ID)== stitchPolygons[p->index]->constraintID.end()) //no conflict
			p = p->p;
		else
			return false;
	}
	return true;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Check whether two graph nodes are compatible with each other. If compatible, we need to add an edge in the graph
 between the two nodes
 a is the node we already have. b is the new node we want to check
 -----------------------------------------------------------------------------------------------------------------------------------------*/
bool standardCell::checkGraphLegal(node *&b, node *&a) {
	map<int, char>::iterator cutlineIT, findIT;
	set<int>::iterator constraintIDIT;
	for (cutlineIT = a->cutline.begin(); cutlineIT != a->cutline.end();	cutlineIT++) {
		if ((findIT = b->cutline.find(cutlineIT->first)) != b->cutline.end()) { //if this polygon also exist in b, we require them to be the same color in both a and b
			if (cutlineIT->second != findIT->second) //if not the same color
				return false;
		}
		for (constraintIDIT = stitchPolygons[cutlineIT->first]->constraintID.begin();
				constraintIDIT != stitchPolygons[cutlineIT->first]->constraintID.end();constraintIDIT++) {
			if ((findIT = b->cutline.find((*constraintIDIT)))!= b->cutline.end()) { //for a polygon in a, some polygons in b conflict with it
				if (findIT->second == cutlineIT->second) // if conflict happens
					return false;
			}
		}
	}
	return true;
}


bool polygonIntersect(polygon *a, polygon *b){
	vector< pair<int,int> >::iterator firstaIT,secondaIT,firstbIT, secondbIT;
	firstaIT=a->vertXYCoord.begin();
	secondaIT=a->vertXYCoord.begin();
	secondaIT++;
	
	for(;secondaIT!=a->vertXYCoord.end();firstaIT++, secondaIT++){
		firstbIT=b->vertXYCoord.begin();
		secondbIT=b->vertXYCoord.begin();
		secondbIT++;
		if(firstaIT->first==secondaIT->first && firstaIT->second!=secondaIT->second){  // vertical
			for(;secondbIT!=b->vertXYCoord.end();firstbIT++, secondbIT++){
				if(firstbIT->first==secondbIT->first && firstbIT->first==firstaIT->first && firstbIT->second!=secondbIT->second){ // vertical
					if((WITHIN(firstaIT->second, secondaIT->second, firstbIT->second)) 
							|| (WITHIN(firstaIT->second, secondaIT->second, secondbIT->second))
							|| (WITHIN(firstbIT->second, secondbIT->second, firstaIT->second))
							|| (WITHIN(firstbIT->second, secondbIT->second, secondaIT->second)))
						return true;
				}
			}	
		}
		else if(firstaIT->second==secondaIT->second && firstaIT->first!=secondaIT->first){  // horizontal
			for(;secondbIT!=b->vertXYCoord.end();firstbIT++, secondbIT++){
				if(firstbIT->first!=secondbIT->first && firstbIT->second==firstaIT->second && firstbIT->second==secondbIT->second){ // horizontal 
					if((WITHIN(firstaIT->first, secondaIT->first, firstbIT->first)) 
							|| (WITHIN(firstaIT->first, secondaIT->first, secondbIT->first))
							|| (WITHIN(firstbIT->first, secondbIT->first, firstaIT->first))
							|| (WITHIN(firstbIT->first, secondbIT->first, secondaIT->first)))
						return true;
				}	
			}			
		}
	}	
	return false;
}


/*-----------------------------------------------------------------------------------------------------------------------------------------
Find ancestors in the solution graph for current graph node
 -----------------------------------------------------------------------------------------------------------------------------------------*/
int standardCell::findAncestor(node *&solutionNode, set<node*> &currNode,set<int> & newPolygonID) {
	set<node*>::iterator currNodeIT;
	int num = 0, cost(0);
	node * curr;
	for (currNodeIT = currNode.begin(); currNodeIT != currNode.end();currNodeIT++) {
		curr = (*currNodeIT);
		if (checkGraphLegal(solutionNode, curr)) { //if compatible, we add an edge between the two nodes
			cost=determineEdgeCost(curr,solutionNode,newPolygonID);
			(*currNodeIT)->next.insert(pair<node *, int> (solutionNode, cost));
			solutionNode->pre.insert(pair<node *, int> (curr, cost));
			num++;
		}
	}
	return num;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
Free the node memory created in standardCell::constructNode
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void standardCell::freeTree(treeNode *root) {
	queue<treeNode *> allNodes;
	allNodes.push(root);
	treeNode * curr;
	while (!allNodes.empty()) {
		curr = allNodes.front();
		if (curr->left != NULL)
			allNodes.push(curr->left);
		if (curr->right != NULL)
			allNodes.push(curr->right);
		if (curr->middle != NULL)
			allNodes.push(curr->middle);
		delete (curr);
		allNodes.pop();
	}
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
After reducing the graph, we have to update the node ID
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void standardCell::assignNodeID(bool sameFlag){
	set<node*> currNode, preNode;
	set<node*>::iterator currNodeIT, preNodeIT;
	map<_NODE *, int>::iterator nextIT;
	if(sameFlag){
		currNode.insert(headSame);
		preNode.insert(headSame);
	}
	else{
		currNode.insert(headDiff);
		preNode.insert(headDiff);		
	}
	int index=0;
	while(!currNode.empty()){
		preNode=currNode;
		currNode.clear();
		index=0;
		for(preNodeIT=preNode.begin();preNodeIT!=preNode.end();preNodeIT++){
			(*preNodeIT)->ID=index++;
			for(nextIT=(*preNodeIT)->next.begin();nextIT!=(*preNodeIT)->next.end();nextIT++)
				currNode.insert(nextIT->first);
		}
	}
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
reduce the graph if the node has no descents
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void standardCell::reduceGraph(set<node*> & currNode){	
	set<node*>::iterator currNodeIT;
	map<_NODE *, int>::iterator preIT;
	queue<node *>  nodeQueue;
	vector<node *> toErase;
	vector<node *>::iterator toEraseIT;
	node * curr,  *nodeNow;
	set<node *>  cutlineNode;
	set<node *>::iterator  cutlineNodeIT;
	for(currNodeIT=currNode.begin();currNodeIT!=currNode.end();currNodeIT++){
		if((*currNodeIT)->next.empty()){
			nodeQueue.push((*currNodeIT));
			while (!nodeQueue.empty()) {
				while (!nodeQueue.empty()) {
					curr = nodeQueue.front();
					nodeQueue.pop();
					if (curr->next.empty()) {
						for (preIT = curr->pre.begin();preIT != curr->pre.end(); preIT++) {
							nodeNow = preIT->first;
							nodeNow->next.erase(curr);
//							nodeQueue.push(nodeNow);
							cutlineNode.insert(nodeNow);
						}
//						printf("\nDelete node\n");
//						displayNode(curr);
						delete (curr);

					}
				}
				for(cutlineNodeIT=cutlineNode.begin();cutlineNodeIT!=cutlineNode.end();cutlineNodeIT++)
					nodeQueue.push(*cutlineNodeIT);
				cutlineNode.clear();
			}
			toErase.push_back(*currNodeIT);	
		}			
	}
	for(toEraseIT=toErase.begin();toEraseIT!=toErase.end();toEraseIT++)
		currNode.erase((*toEraseIT));
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Three coloring solution: construct the graph node
 -----------------------------------------------------------------------------------------------------------------------------------------*/
bool standardCell::constructNode(set<node*> & currNode, set<int> & polygonID,set<node*> & nextNode,bool sameFlag,set<int> & newPolygonID) {
	queue<treeNode *> allNodes, temp;
	treeNode *root = new treeNode;
	root->index = -1;
	root->color = -1;
	root->left = NULL;
	root->middle = NULL;
	root->right = NULL;
	
	set<int>::iterator polygonIDIT;
	int ID;
	treeNode * curr=root;
	if(sameFlag){  //VDD GND same color
		treeNode *left;
		left=new treeNode;
		left->index = 0;
		left->color = 0;
		left->p = curr;
		left->left = NULL;
		left->middle = NULL;
		left->right = NULL;
		curr->left = left;
		curr=curr->left;
		
		left=new treeNode;
		left->index = 1;
		left->color = 0;
		left->p = curr;
		left->left = NULL;
		left->middle = NULL;
		left->right = NULL;
		curr->left = left;
		curr=curr->left;
	}
	else{  //VDD GND different color
		treeNode *left, *middle;
		left=new treeNode;
		left->index = 0;
		left->color = 0;
		left->p = curr;
		left->left = NULL;
		left->middle = NULL;
		left->right = NULL;
		curr->left = left;
		curr=curr->left;
		
		middle=new treeNode;
		middle->index = 1;
		middle->color = 1;
		middle->p = curr;
		middle->left = NULL;
		middle->middle = NULL;
		middle->right = NULL;
		curr->middle = middle;
		curr=curr->middle;
	}
	allNodes.push(curr);

	for (polygonIDIT = polygonID.begin(); polygonIDIT != polygonID.end();polygonIDIT++) {
		ID = *polygonIDIT;
//		printf("Current ID is %d\n",ID);
		if(ID<=1)
			continue;
		temp = allNodes;
		while (!temp.empty()) {
			curr = temp.front();
			treeNode *left, *middle, *right;
			if (checkLegal(ID, curr, 0)) { //If left node is compatible with previous color assignment
				left = new treeNode;
				left->color = 0;
				left->index = ID;
				left->p = curr;
				left->left = NULL;
				left->middle = NULL;
				left->right = NULL;
				curr->left = left;
				allNodes.push(left);
			} else
				curr->left = NULL;

			if (checkLegal(ID, curr, 1)) { //If middle node is compatible with previous color assignment
				middle = new treeNode;
				middle->color = 1;
				middle->index = ID;
				middle->p = curr;
				middle->left = NULL;
				middle->middle = NULL;
				middle->right = NULL;
				curr->middle = middle;
				allNodes.push(middle);
			} else
				curr->middle = NULL;

			if (checkLegal(ID, curr, 2)) { //If right node is compatible with previous color assignment
				right = new treeNode;
				right->color = 2;
				right->index = ID;
				right->p = curr;
				right->left = NULL;
				right->middle = NULL;
				right->right = NULL;
				curr->right = right;
				allNodes.push(right);
			} else
				curr->right = NULL;
			temp.pop();
			allNodes.pop();
		}
	} //end for

	int ancesNum = 0;
	bool nosolutionFlag=true;
//	printf("allNodes size is %d\n",allNodes.size());
	while (!allNodes.empty()) {
		curr = allNodes.front();
		allNodes.pop();
		node *solutionNode = new node; //final solution node in the graph
		while (curr->color != -1) {
			solutionNode->cutline.insert(pair<int, char>(curr->index, curr->color));
			curr = curr->p;
		}
		ancesNum = findAncestor(solutionNode, currNode,newPolygonID);
		if (!ancesNum) //if no ancestors
			delete (solutionNode);
		else{
//			solutionNode->cost=determineNodeCost(solutionNode,newPolygonID);
			solutionNode->cost=0;
			solutionNode->distance= MAXIMUM;
			nextNode.insert(solutionNode); //otherwise, save it in the next solution node set
			nosolutionFlag=false;
		}
	}
	
	if(nosolutionFlag){
		printf("For cell %s, sameFlag is %d, fail to find a 3-colorable solution!\n",name,sameFlag);
		return false;
	}
	
	reduceGraph(currNode);  //For currNode, if node has no descents, delete it
	freeTree(root);
	return true;
}

/*-----------------------------------------------------------------------------------------------------------------------------------------
 Three coloring solution of the standard cells
 -----------------------------------------------------------------------------------------------------------------------------------------*/
bool standardCell::enmurateColor(bool sameFlag) {
	virtualExtend(); //first get the virtual boundary of the polygons
	vector<polygon *>::iterator polygonIT;
	int cutCoord, cutID = 0;
	set<int> polygonID, newPolygonID;
	set<int>::iterator polygonIDIT;
	set<node*> currNode, nextNode;
	node *head;
	int index, leftX;
	if(sameFlag){
		headSame = new node;
		head=headSame;
	}
	else{
		headDiff = new node;
		head=headDiff;
	}
	head->ID=0;
	currNode.insert(head);
	nextNode.insert(head);
	for (polygonIT = stitchPolygons.begin(); polygonIT != stitchPolygons.end();	polygonIT++) {
//		printf("Now processing polygon ID is %d\n",(*polygonIT)->index);
		if((*polygonIT)->index<2){   //neglect VDD and GND
//			printf("Now polygon left B is %d, rightB is %d,  upB is %d\n",(*polygonIT)->leftB,(*polygonIT)->rightB,(*polygonIT)->upB);
			continue;
		}
		currNode = nextNode;
		nextNode.clear();
		cutCoord = (*polygonIT)->leftB;
		for (polygonIDIT = polygonID.begin(); polygonIDIT != polygonID.end();polygonIDIT++) {
			index = *polygonIDIT;
			if (!WITHIN(stitchPolygons[index]->leftB, stitchPolygons[index]->virtualRight,cutCoord)) {
				polygonID.erase(index); //the polygon is no longer being cut, so remove it from the set
			}
		}
		newPolygonID.clear();
		//please note that some polygons may have the same x coordinate!
		while (polygonIT != stitchPolygons.end() && (*polygonIT)->leftB == cutCoord) {
//			printf(	"cutID=%d,  Inserted index is %d, polygon left boundary is %d\n",cutID, (*polygonIT)->index, (*polygonIT)->leftB);
			polygonID.insert((*polygonIT)->index);
			newPolygonID.insert((*polygonIT)->index);
			polygonIT++;
		}
		polygonIT--;
		cutID++;
		if(!constructNode(currNode, polygonID, nextNode,sameFlag,newPolygonID)){
			printf("For cell %s, no solution when sameFlag is %d\n",name,sameFlag);
			return false;
		}
	}
	assignNodeID(sameFlag);
	return true;
}


/*-----------------------------------------------------------------------------------------------------------------------------------------
Get the left and right boundaries of the polygon
 -----------------------------------------------------------------------------------------------------------------------------------------*/
void getPolygonBoundary(polygon * curr){
	vector< pair<int,int> >::iterator vertXYCoordIT;
	int leftB=MAXIMUM, rightB=MINIMUM, upB=MINIMUM;
	for(vertXYCoordIT=curr->vertXYCoord.begin();vertXYCoordIT!=curr->vertXYCoord.end();vertXYCoordIT++){
		if(leftB>vertXYCoordIT->first)
			leftB=vertXYCoordIT->first;
		if(rightB<vertXYCoordIT->first)
			rightB=vertXYCoordIT->first;
		if(upB<vertXYCoordIT->second)
			upB=vertXYCoordIT->second;
	}
	curr->leftB=leftB;
	curr->rightB=rightB-1;  // offset by 1	
	curr->upB=upB;
	curr->numVertix=curr->vertXYCoord.size();
}
















