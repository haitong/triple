#ifndef __XFIG_H__
#define __XFIG_H__
#include <stdio.h>
#include "preProcess.h"

void drawSingleCell(standardCell *currCell);
void drawCell();
void outputSolution();
#endif
