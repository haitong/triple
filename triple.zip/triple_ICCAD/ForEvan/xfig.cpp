#include "xfig.h"
#include "preProcess.h"
#include <vector>
#include <string.h>
#include <map>
#include <set>
#include <queue>
#include <math.h>
#include <iostream>
#include <stdlib.h>
#define shiftID  1000000  //set it to be a sufficiencly large number to ensure no ID conflicts between polygons in pre cell and curr cell
extern map<string, standardCell *> cellLib;

using namespace std;

void drawSingleCell(standardCell *currCell){
	FILE * fp;
	vector<polygon *>::iterator  polygonsIT;
	vector<edge *>::iterator conflictEdgeIT;
	vector< pair<int,int> >::iterator vertXYCoordIT;
	
	char fileName[100];
	strcpy(fileName,"./figure/");
	strcat(fileName,currCell->name);
	strcat(fileName,".fig");
	if((fp=fopen(fileName,"w"))==NULL){
		printf("In drawCell, Cannot open file %s!\n",fileName);
		abort();
	}
	fprintf(fp,"#FIG 3.2\n");
	fprintf(fp,"Landscape\n");
	fprintf(fp,"Center\n");
	fprintf(fp,"Inches\n");
	fprintf(fp,"Letter\n");
	fprintf(fp,"100\n");  //float	magnification		(export and print magnification, %)
	fprintf(fp,"Multiple\n");
	fprintf(fp,"-2\n");
	fprintf(fp,"1200 2\n");
	for(polygonsIT=currCell->polygons.begin();polygonsIT!=currCell->polygons.end();polygonsIT++){
		fprintf(fp, "2 1 0 1 0 -1 1 0 -1 0.00 0 0 -1 0 0 %d\n",(*polygonsIT)->vertXYCoord.size());
		fprintf(fp, "\t ");
		for(vertXYCoordIT=(*polygonsIT)->vertXYCoord.begin();vertXYCoordIT!=(*polygonsIT)->vertXYCoord.end();vertXYCoordIT++){
			fprintf(fp, "%d  %d  ", vertXYCoordIT->first,-1*vertXYCoordIT->second);
		}
		fprintf(fp, "\n");
		
		for(conflictEdgeIT=(*polygonsIT)->conflictEdge.begin();conflictEdgeIT!=(*polygonsIT)->conflictEdge.end();conflictEdgeIT++){
			fprintf(fp,"2 1 0 10 4 0 0 0 -1 10 0 0 0 0 0 2\n");
			fprintf(fp, "\t ");
			fprintf(fp, "%d  %d  %d  %d",(*conflictEdgeIT)->thisX, -1*(*conflictEdgeIT)->thisY, (*conflictEdgeIT)->thatX, -1*(*conflictEdgeIT)->thatY);
			fprintf(fp, "\n");
		}
	}
	vector<edge*>::iterator stitchEdgeVecIT;
	for(stitchEdgeVecIT=currCell->stitchEdgeVec.begin();stitchEdgeVecIT!=currCell->stitchEdgeVec.end();stitchEdgeVecIT++){
		fprintf(fp, "2 1 0 1 0 -1 1 0 -1 0.00 0 0 -1 0 0 2\n");
		fprintf(fp, "%d  %d  %d  %d", (*stitchEdgeVecIT)->thisX,-1*(*stitchEdgeVecIT)->thisY,(*stitchEdgeVecIT)->thatX,-1*(*stitchEdgeVecIT)->thatY);
		fprintf(fp, "\n");		
	}
	fclose(fp);
	
	strcpy(fileName,"./figure/");
	strcat(fileName,currCell->name);
	strcat(fileName,"Decompose.fig");
	if((fp=fopen(fileName,"w"))==NULL){
		printf("In drawCell, Cannot open file %s!\n",fileName);
		abort();
	}
	fprintf(fp,"#FIG 3.2\n");
	fprintf(fp,"Landscape\n");
	fprintf(fp,"Center\n");
	fprintf(fp,"Inches\n");
	fprintf(fp,"Letter\n");
	fprintf(fp,"100\n");  //float	magnification		(export and print magnification, %)
	fprintf(fp,"Multiple\n");
	fprintf(fp,"-2\n");
	fprintf(fp,"1200 2\n");
	for(polygonsIT=currCell->stitchPolygons.begin();polygonsIT!=currCell->stitchPolygons.end();polygonsIT++){
//		fprintf(fp, "2 1 0 1 %d -1 1 0 -1 0.00 0 0 -1 0 0 %d\n",(*polygonsIT)->parentID,(*polygonsIT)->vertXYCoord.size());
		fprintf(fp, "2 1 0 1 0 -1 1 0 -1 0.00 0 0 -1 0 0 %d\n",(*polygonsIT)->vertXYCoord.size());
		fprintf(fp, "\t ");
		for(vertXYCoordIT=(*polygonsIT)->vertXYCoord.begin();vertXYCoordIT!=(*polygonsIT)->vertXYCoord.end();vertXYCoordIT++){
			fprintf(fp, "%d  %d  ", vertXYCoordIT->first,-1*vertXYCoordIT->second);
		}
		fprintf(fp, "\n");
	}
	for(polygonsIT=currCell->stitchPolygons.begin();polygonsIT!=currCell->stitchPolygons.end();polygonsIT++){
		for(conflictEdgeIT=(*polygonsIT)->conflictEdge.begin();conflictEdgeIT!=(*polygonsIT)->conflictEdge.end();conflictEdgeIT++){
			fprintf(fp,"2 1 0 10 4 0 0 0 -1 10 0 0 0 0 0 2\n");
			fprintf(fp, "\t ");
			fprintf(fp, "%d  %d  %d  %d",(*conflictEdgeIT)->thisX, -1*(*conflictEdgeIT)->thisY, (*conflictEdgeIT)->thatX, -1*(*conflictEdgeIT)->thatY);
			fprintf(fp, "\n");
		}
	}
	for(stitchEdgeVecIT=currCell->stitchEdgeVec.begin();stitchEdgeVecIT!=currCell->stitchEdgeVec.end();stitchEdgeVecIT++){
		fprintf(fp, "2 1 0 1 0 -1 1 0 -1 0.00 0 0 -1 0 0 2\n");
		fprintf(fp, "%d  %d  %d  %d", (*stitchEdgeVecIT)->thisX,-1*(*stitchEdgeVecIT)->thisY,(*stitchEdgeVecIT)->thatX,-1*(*stitchEdgeVecIT)->thatY);
		fprintf(fp, "\n");		
	}
	fclose(fp);
}


/*-----------------------------------------------------------------------------------------------------------------------------------------
Display the solution: using xfig

	     0 = Black
	     1 = Blue
	     2 = Green
	     3 = Cyan
	     4 = Red
	     5 = Magenta
	     6 = Yellow
	     7 = White
	  8-11 = four shades of blue (dark to lighter)
	 12-14 = three shades of green (dark to lighter)
	 15-17 = three shades of cyan (dark to lighter)
	 18-20 = three shades of red (dark to lighter)
	 21-23 = three shades of magenta (dark to lighter)
	 24-26 = three shades of brown (dark to lighter)
	 27-30 = four shades of pink (dark to lighter)
	    31 = Gold
-----------------------------------------------------------------------------------------------------------------------------------------*/
void drawCell(){
	map<string, standardCell *>::iterator cellLibIT;
	map<int, char>::iterator  cutlineIT;
	node *nodeNow, *curr;
	standardCell *cellNow;
	polygon *currP;
	char cellName[50]={0};
	set<node *> currNode, preNode;
	set<node *>::iterator currNodeIT, preNodeIT;
	map<node *, int>::iterator nextIT;
	int width=1000, height=1000, xDis=10000, yDis=5000;

	vector<pair<int, int> >::iterator vertXYCoordIT;
	
	for (cellLibIT = cellLib.begin(); cellLibIT != cellLib.end(); cellLibIT++) {
		FILE *fp;
		curr = cellLibIT->second->headSame;
		cellNow = cellLibIT->second;
		strcpy(cellName,"./figure/");
		strcat(cellName,cellNow->name);
		strcat(cellName,".fig");
//		printf("Now drawing %s\n",cellName);
		fp=(FILE *)fopen(cellName,"w");
		fprintf(fp,"#FIG 3.2\n");
		fprintf(fp,"Landscape\n");
		fprintf(fp,"Center\n");
		fprintf(fp,"Inches\n");
		fprintf(fp,"Letter\n");
		fprintf(fp,"100\n");  //float	magnification		(export and print magnification, %)
		fprintf(fp,"Multiple\n");
		fprintf(fp,"-2\n");
		fprintf(fp,"1200 2\n");
		while (!curr->next.empty()) {
			curr = curr->next.begin()->first;
			for (cutlineIT = curr->cutline.begin();cutlineIT != curr->cutline.end(); cutlineIT++) {
				currP = cellNow->stitchPolygons[cutlineIT->first]; // locate current polygon we want to draw
				fprintf(fp, "2 1 0 1 %d -1 1 0 -1 0.00 0 0 -1 0 0 %d\n",cutlineIT->second, currP->vertXYCoord.size());
				fprintf(fp, "\t ");
				for (vertXYCoordIT = currP->vertXYCoord.begin();vertXYCoordIT != currP->vertXYCoord.end();vertXYCoordIT++) {
					fprintf(fp, "%d  %d  ", vertXYCoordIT->first,vertXYCoordIT->second);
				}
				fprintf(fp, "\n");
			}
		}
		fclose(fp);
		
		//every node is represented by a 10*10 rectangles
		int level=1,x=0,y=0,preX, preY;
		curr = cellLibIT->second->headSame;
		currNode.insert(cellLibIT->second->headSame);
		preNode.insert(cellLibIT->second->headSame);
		cellNow = cellLibIT->second;
		strcpy(cellName,"./figure/");
		strcat(cellName,"rec");
		strcat(cellName,cellNow->name);
		strcat(cellName,".fig");
//		printf("Now drawing %s\n",cellName);
		fp=(FILE *)fopen(cellName,"w");
		fprintf(fp,"#FIG 3.2\n");
		fprintf(fp,"Landscape\n");
		fprintf(fp,"Center\n");
		fprintf(fp,"Inches\n");
		fprintf(fp,"Letter\n");
		fprintf(fp,"100\n");  //float	magnification		(export and print magnification, %)
		fprintf(fp,"Multiple\n");
		fprintf(fp,"-2\n");
		fprintf(fp,"1200 2\n");
		fprintf(fp, "2 1 0 1 1 -1 1 0 -1 0.00 0 0 -1 0 0 5\n");
		fprintf(fp, "\t ");
		fprintf(fp,"%d %d %d %d %d %d %d %d %d %d \n",-width/2,-width/2, width/2, -width/2, width/2, width/2, -width/2, width/2,-width/2,-width/2); 
		while (!currNode.empty()) {
			x=xDis*level;
			preX=xDis*(level-1);
			preNode=currNode;
			currNode.clear();
			for(preNodeIT=preNode.begin();preNodeIT!=preNode.end();preNodeIT++){
				preY=yDis*(*preNodeIT)->ID;
				for(nextIT=(*preNodeIT)->next.begin();nextIT!=(*preNodeIT)->next.end();nextIT++){
					currNode.insert(nextIT->first);
					y=yDis*(*nextIT).first->ID;
					fprintf(fp, "2 1 0 1 1 -1 1 0 -1 0.00 0 0 -1 0 0 2\n");
					fprintf(fp, "\t ");
					fprintf(fp,"%d  %d  %d  %d\n",x,y,preX,preY);
				}
			}
			for(currNodeIT=currNode.begin();currNodeIT!=currNode.end();currNodeIT++){
				y=yDis*(*currNodeIT)->ID;
				fprintf(fp, "2 1 0 1 1 -1 1 0 -1 0.00 0 0 -1 0 0 5\n");
				fprintf(fp, "\t ");
				fprintf(fp,"%d  %d  %d  %d  %d  %d  %d  %d  %d  %d  \n",x-width/2,y-width/2,x+width/2,y-width/2,x+width/2,y+width/2,x-width/2,y+width/2,x-width/2,y-width/2);
			}
			level++;
		}	
		fclose(fp);		
	}
}


/*-----------------------------------------------------------------------------------------------------------------------------------------
Display the solution: using xfig

	     0 = Black
	     1 = Blue
	     2 = Green
	     3 = Cyan
	     4 = Red
	     5 = Magenta
	     6 = Yellow
	     7 = White
	  8-11 = four shades of blue (dark to lighter)
	 12-14 = three shades of green (dark to lighter)
	 15-17 = three shades of cyan (dark to lighter)
	 18-20 = three shades of red (dark to lighter)
	 21-23 = three shades of magenta (dark to lighter)
	 24-26 = three shades of brown (dark to lighter)
	 27-30 = four shades of pink (dark to lighter)
	    31 = Gold
-----------------------------------------------------------------------------------------------------------------------------------------*/
void outputSolution(){
	drawCell();
	FILE *fp;
	fp=(FILE *)fopen("./figure/tripple.fig","w");
	fprintf(fp,"#FIG 3.2\n");
	fprintf(fp,"Landscape\n");
	fprintf(fp,"Center\n");
	fprintf(fp,"Inches\n");
	fprintf(fp,"Letter\n");
	fprintf(fp,"100\n");  //float	magnification		(export and print magnification, %)
	fprintf(fp,"Multiple\n");
	fprintf(fp,"-2\n");
	fprintf(fp,"1200 2\n");

	map<string, standardCell *>::iterator cellLibIT;
	map<int, char>::iterator  cutlineIT;
	node *currNode;
	standardCell *cellNow;
	polygon *currP;

	vector< pair<int,int> >::iterator vertXYCoordIT;

	int track=0,depth=0,i,index=0, rightB=0, color;
	vector<bool> drawFlag;
	vector<rowElement *>::iterator cellInRowIT; 
	rowElement * currE;
	for(cellInRowIT=cellInRow.begin();cellInRowIT!=cellInRow.end();cellInRowIT++,track++){
		currE=(*cellInRowIT)->next;
		currNode = graphHead[track]->next.begin()->first;
//		printf("Processing track %d (*cellInRowIT) name is %s\n",track,(*cellInRowIT)->name.c_str());
		while (currE) {
			depth = getCellDepth(currE);
			cellNow = cellLib.find(currE->name)->second;
			drawFlag.clear();
			for (i = 0; i < cellNow->stitchPolygons.size(); i++)
				drawFlag.push_back(false);
			for(i=0;i<depth;i++){
				for(cutlineIT=currNode->cutline.begin();cutlineIT!=currNode->cutline.end();cutlineIT++){
					if(cutlineIT->first >= shiftID)
						if(i==depth-1)
							index=cutlineIT->first-shiftID;
						else continue;
					else index=cutlineIT->first;
					if(!drawFlag[index]){
						currP=cellNow->stitchPolygons[index];   // locate current polygon we want to draw
						if(cutlineIT->second==0)
							color=4;
						else color=cutlineIT->second;
						fprintf(fp,"2 1 0 1 %d -1 1 0 -1 0.00 0 0 -1 0 0 %d\n",color,currP->vertXYCoord.size());
						fprintf(fp,"\t ");
						for(vertXYCoordIT=currP->vertXYCoord.begin();vertXYCoordIT!=currP->vertXYCoord.end();vertXYCoordIT++){
							fprintf(fp,"%ld  %ld  ",vertXYCoordIT->first+currE->xCoord,vertXYCoordIT->second+currE->yCoord);
						}		
						fprintf(fp,"\n");
						areaRandom[(int)cutlineIT->second]+=currP->area;
					}
					else drawFlag[index]=true;
				}
				currNode=currNode->next.begin()->first;  //always choose the first node
			}
			currE=currE->next;
		}		
	}
	fclose(fp);
}






